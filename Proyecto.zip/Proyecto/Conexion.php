<?php
$servername = "localhost";
$username = "root";
$password = "Joahan11.";
$database = "Citas_Medicas";

// Crea una conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verifica la conexión
if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}
echo "Conexión exitosa";
?>
